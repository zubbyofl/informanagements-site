// Site-wide config for WhatsApp button
window.IM_CONFIG = {
  whatsappNumber: "12136425934",
  whatsappMessage: "Hello Info Managements — I’d like to talk."
};
